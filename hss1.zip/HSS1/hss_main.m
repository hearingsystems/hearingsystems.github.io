%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Main script to test and orchestrate the functions written for the Hearing Systems Seminar belonging to the Hearing
% Systems Lectures, which were held for the first time in winter semester 2020 as part of the Audio Systems Technology
% lecture series at TU Ilmenau.
%
% Please contact Dr.-Ing. Tamas Harczos at tamas.harczos@audifon.com if you have questions.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% uncomment these if you like your workspace cleared and previous figures be closed upon start
% clear all
% close all


%% audio file to work with (uncomment ONE at a time)
aud_file= 'sounds\Ansi.wav';
% aud_file= 'sounds\Jumpy.wav';
% aud_file= 'sounds\AzBio1.wav';
% aud_file= 'sounds\AzBio2.wav';
% aud_file= 'sounds\Music1.wav';
% aud_file= 'sounds\Music2.wav';
% aud_file= 'sounds\Music3.wav';

%% here we can define our settings
rms_window_ms= 10;        % length of one RMS window 

attack_time_ms= 1;        % attack time in ms (~how fast gain will be reduced if necessary)
release_time_ms= 10;      % release time in ms (~how fast gain will be increased if necessary)

limiter_db= -20;          % dB FS (RMS) value above which we want to limit the output

compressor_knees_db= ...  % compressor knee point definitions as [input_db, output_db] pairs
  [-192, -192; ...
    -90, -100; ...
    -75,  -60; ...
    -50,  -35; ...
    -25,  -30; ...
    -10,  -15; ...
      0,  -15];     
    
%% uncomment the following block to see how the compressor definition looks like    
% figure;
% plot(compressor_knees_db(2:end,1),compressor_knees_db(2:end,2),'o-');
% line([compressor_knees_db(2,1),0],[compressor_knees_db(2,1),0],'LineStyle',':','Color',[1 0 0]);
% xlabel('Input (dB FS RMS)'); ylabel('Output (dB FS RMS)');
% return;

%% load audio file, also acquire sampling rate
[audio,fs]= audioread(aud_file);


%% --------------------------------------------------------------------------------------------------------------------
% call our function to determine RMS profile of the input
audio_rms_profile= hss_rms(audio, fs, rms_window_ms);


% %% --------------------------------------------------------------------------------------------------------------------
% % call our function to apply limiter above given dB FS (RMS) level
% audio_limited= hss_limiter(audio, fs, audio_rms_profile, limiter_db, attack_time_ms, release_time_ms);
% 
% % determine RMS profile of the limited audio
% audio_limited_rms_profile= hss_rms(audio_limited, fs, rms_window_ms);


% %% --------------------------------------------------------------------------------------------------------------------
% % call our function to apply compression
% audio_compressed= hss_compressor(audio, fs, audio_rms_profile, compressor_knees_db, attack_time_ms, release_time_ms);
% 
% % determine RMS profile of the compressed audio
% audio_compressed_rms_profile= hss_rms(audio_compressed, fs, rms_window_ms);


%% --------------------------------------------------------------------------------------------------------------------
% play back processed audio (uncomment ONE of the following lines to hear the audio signal)

% playback_signal= audio;
% playback_signal= audio_limited;
% playback_signal= audio_compressed;

if exist('playback_signal','var') && ~isempty(playback_signal)
  player= audioplayer(playback_signal,fs);
  play(player);
end


%% --------------------------------------------------------------------------------------------------------------------
% plot everything what we have so far
figure;
subplot(4,1,1);
plot(audio);
ylabel('Waveform');
xlim([0,length(audio)]);

subplot(4,1,2:4);

if exist('audio_rms_profile','var')
  
  plot(audio_rms_profile, ...
    'Color',[.4 .4 .4], 'LineWidth',1.5, ...
    'DisplayName','Input signal');
  
  xlabel('Time (samples)');
  ylabel('dB FS (RMS)');
  
  xlim([0,length(audio)]);
  ylim([-92,0]); 
  hold on;
  
end

if exist('audio_limited_rms_profile','var')

  plot(audio_limited_rms_profile, ...
    'Color',[1 .2 .2], 'LineWidth',2, 'LineStyle',':', ...
    'DisplayName',['Limited at ' num2str(limiter_db) ' dB']);
  
end

if exist('audio_compressed_rms_profile','var')

  plot(audio_compressed_rms_profile, ...
    'Color',[.2 .2 1], 'LineWidth',1.5, 'LineStyle','--', ...
    'DisplayName','Compressed');
    
end

legend('Location','SouthEast');
