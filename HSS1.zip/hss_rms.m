function rms_profile= hss_rms(a,fs,rms_window_ms)
% function rms_profile= hss_rms(a,fs,rms_window_ms)
%
% This function scans the provided vector of audio samples with a sliding window and determines the RMS (in dB FS)
% at every sample position (the current sample being the last one in the sliding window). The returned column vector
% of RMS values has the same size as the input vector of audio samples.
%
% [Parameters]
%              a: column vector of audio samples
%             fs: sampling rate in sps (samples per second)
%  rms_window_ms: length of the sliding window in ms (millisecond)
%
% [Return value]
%    rms_profile: column vector of RMS values
%
% This file was provided for the Hearing Systems Seminar belonging to the Hearing Systems Lectures, which were held
% for the first time in winter semester 2020 as part of the Audio Systems Technology lecture series at TU Ilmenau.
%
% Please contact Dr.-Ing. Tamas Harczos at tamas.harczos@audifon.com if you have questions.


% TO BE IMPLEMENTED ...
rms_profile= 0;  % <- change me

%% finished
end
